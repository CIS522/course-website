**Opening the Jupyter Notebook**:
1. Go to https://colab.research.google.com
2. You'll be taken to a "Hello, Colaboratory page", click file->Upload Notebook and upload the .ipynb file

**Submission Instructions**:
1. Go to the CIS 700 Canvas Page
2. Go to assignments
3. Go to Homework 0: Finger exercises, and submit ALL of the following files:
  * writeup.pdf (your writeup of the CODE section of the assignment)
  * written.pdf (your writeup of the WRITTEN portion of the pdf)
  * HW0.ipynb

We will **only** be grading the pdf files you submit (so don't worry about code style), however, we will also be detecting plagiarism in submissions. Any violation of the collaboration policy outlined in the homework will be sent to the Office of Student Conduct (OSC). 

