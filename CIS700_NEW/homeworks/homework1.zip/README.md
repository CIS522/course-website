**Submission Instructions**:
1. Go to the CIS 700 Canvas Page
2. Go to assignments
3. Go to Homework 1: Deep Learning Diagnosis, and submit ALL of the following files:
  * writeup.pdf (since there is no written portion, this contains the writeup for all CODE related questions)
  * HW1.ipynb

We will **only** be grading the pdf files you submit (so don't worry about code style), however, we will also be detecting plagiarism in submissions. Any violation of the collaboration policy outlined in the homework will be sent to the Office of Student Conduct (OSC). 

This assignment will be due **February 22nd, 2019** at **11:59pm**
